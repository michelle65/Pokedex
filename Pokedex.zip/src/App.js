import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import AppNavigator from "./components/AppNavigator";
import Pokedex from "./containers/Pokedex";
import PokemonDetails from "./containers/PokemonDetails";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";

import { store, persistor } from "./redux/store";
import Favourites from "./containers/Favourites";
export default function App() {
  return (
    /* <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter>
          <AppNavigator />
          <Routes>
            <Route path="/" component={<Pokedex />} />
            <Route path="/pokemon/:id" element={<PokemonDetails />} />
            */
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter>
          <AppNavigator />
          <Routes>
            <Route exact path="/" element={<Pokedex/>} component={Pokedex} />
            <Route exact path="/pokemon/:id" element={<PokemonDetails/>} component={PokemonDetails} />
            <Route exact path="/favourites" element={<Favourites/>} component={Favourites} />
          </Routes>
        </BrowserRouter>
      </PersistGate>
    </Provider>
  );
}
