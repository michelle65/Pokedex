export const POKEMON_API_URL = "https://pokeapi.co/api/v2/pokemon"
export const IMAGE_API_URL = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/"
//export const IMAGE_API_URL = "https://github.com/PokeAPI/sprites/tree/master/sprites/pokemon"
